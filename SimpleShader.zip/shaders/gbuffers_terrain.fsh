#version 120

#define LIGHT_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5] Directional shading strength
#define CAVE_STRENGTH 0.25 // [0.0 0.25 0.5 0.75 1.0] Cave contrast strength
#define CAVE_DARKNESS_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0] Sky-blocked cave darkness
#define WARMTH_STRENGTH 0.5 // [0.0 0.25 0.5 0.75 1.0] Warm block light strength
#define BLOCK_LIGHT_BOOST 0.25 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5] Block light brightness boost
#define EMISSIVE_CORE_STRENGTH 0.5 // [0.0 0.25 0.5 0.75 1.0 1.25 1.5] Bright source core strength
#define NIGHT_LIGHTING_STRENGTH 1.5 // [0.0 0.5 1.0 1.5 2.0 2.5 3.0] Night darkness and blue reduction strength
#define EMISSIVE_RADIUS 0.75 // [0.25 0.5 0.75 1.0 1.25 1.5 2.0 3.0 4.0] Apparent block light radius
#define WATER_TONE_STRENGTH 1.0 // [0.0 0.25 0.5 0.75 1.0] Water tone strength
#define WATER_TINT_STRENGTH 0.5 // [0.0 0.25 0.5 0.75 1.0] Blue-green water tint strength
#define WATER_HIGHLIGHT_STRENGTH 0.35 // [0.0 0.15 0.3 0.45 0.6 0.8] Sun/moon water highlight strength
#define MOONLIGHT_STRENGTH 0.75 // [0.0 0.25 0.5 0.75 1.0 1.5 2.0] Neutral moonlight strength
#define ENABLE_CAVE_CONTRAST // Toggle cave contrast
#define ENABLE_CAVE_DARKNESS // Toggle darker caves
#define ENABLE_WARM_LIGHT // Toggle warm block light
#define ENABLE_BLOCK_LIGHT_BOOST // Toggle block light boost
#define ENABLE_EMISSIVE_CORE // Toggle emissive source core boost
#define ENABLE_NIGHT_LIGHTING // Toggle darker, more neutral night lighting
#define ENABLE_MOONLIGHT // Toggle soft neutral moonlight
#define ENABLE_EMISSIVE_RADIUS // Toggle apparent light spill radius
#define ENABLE_WATER_TONE // Toggle darker, less saturated water
#define ENABLE_WATER_HIGHLIGHTS // Toggle sun/moon water highlights

uniform sampler2D gtexture;
uniform sampler2D lightmap;
uniform float alphaTestRef = 0.1;
uniform int worldTime;
uniform float frameTimeCounter;
uniform vec3 sunPosition;
uniform vec3 moonPosition;
uniform mat4 gbufferModelViewInverse;

varying vec4 vertexColor;
varying vec2 texcoord;
varying vec2 lightCoord;
varying vec3 worldNormal;
varying float sourceBlock;
varying float fluidSurface;
varying vec3 playerPosition;
varying vec3 viewDirection;
varying vec3 viewNormal;

/* DRAWBUFFERS:0 */

void main() {
    vec4 texel = texture2D(gtexture, texcoord);
    vec4 color = texel * vertexColor;
    if (color.a < alphaTestRef) discard;

    vec3 light = texture2D(lightmap, lightCoord).rgb;
    float blockLight = clamp(lightCoord.x * (32.0 / 30.0) - (1.0 / 30.0), 0.0, 1.0);
#ifdef ENABLE_EMISSIVE_RADIUS
    float expandedBlockLight = pow(blockLight, 1.0 / EMISSIVE_RADIUS);
    light *= 1.0 + (expandedBlockLight - blockLight) * 0.75;
#endif
    float nightIn = clamp((float(worldTime) - 12000.0) / 3000.0, 0.0, 1.0);
    float nightOut = clamp((24000.0 - float(worldTime)) / 3000.0, 0.0, 1.0);
    float nightCycle = nightIn * nightOut;
    float skyLight = clamp(lightCoord.y * (32.0 / 30.0) - (1.0 / 30.0), 0.0, 1.0);
    float blockProtection = smoothstep(0.02, 0.40, blockLight);
    float nightSky = nightCycle * skyLight * (1.0 - blockProtection * 0.7);
#ifdef ENABLE_CAVE_DARKNESS
    float caveExposure = (1.0 - smoothstep(0.04, 0.42, skyLight))
                      * (1.0 - smoothstep(0.03, 0.30, blockLight));
    light *= 1.0 - caveExposure * CAVE_DARKNESS_STRENGTH * 0.78;
#endif
#ifdef ENABLE_NIGHT_LIGHTING
    float nightAmount = clamp(nightCycle * NIGHT_LIGHTING_STRENGTH * 0.5, 0.0, 1.0);
    light *= 1.0 - nightAmount * (1.0 - blockProtection) * 0.78;
    light *= 1.0 - nightSky * 0.20;
    light *= vec3(1.0 + nightSky * 0.08, 1.0 + nightSky * 0.02, 1.0 - nightSky * 0.45);
#endif
#ifdef ENABLE_MOONLIGHT
    float moonBoost = nightSky * MOONLIGHT_STRENGTH * 0.55;
    light *= 1.0 + moonBoost;
    light *= vec3(1.0 + moonBoost * 0.025, 1.0 + moonBoost * 0.015, 1.0);
#endif
#ifdef ENABLE_CAVE_CONTRAST
    vec3 contrastLight = smoothstep(vec3(0.0), vec3(1.0), light);
    light = mix(light, contrastLight, CAVE_STRENGTH);
#endif
    color.rgb *= light;

    float vertical = clamp(worldNormal.y, -1.0, 1.0);
    float directionalShade = 1.0 + LIGHT_STRENGTH * (max(vertical, 0.0) * 0.07
                                 - max(-vertical, 0.0) * 0.09);
    color.rgb *= directionalShade;

#ifdef ENABLE_BLOCK_LIGHT_BOOST
    float blockLightAmount = smoothstep(0.08, 0.65, blockLight);
    color.rgb *= 1.0 + blockLightAmount * BLOCK_LIGHT_BOOST * 0.22;
#endif
#ifdef ENABLE_WARM_LIGHT
    float warmAmount = smoothstep(0.08, 0.65, blockLight) * WARMTH_STRENGTH * 0.12;
    color.rgb *= mix(vec3(1.0), vec3(1.12, 1.04, 0.90), warmAmount);
#endif

    float waterMask = fluidSurface * (1.0 - sourceBlock);
#ifdef ENABLE_WATER_TONE
    float waterLuminance = dot(color.rgb, vec3(0.299, 0.587, 0.114));
    color.rgb = mix(color.rgb, vec3(waterLuminance * 0.25), WATER_TONE_STRENGTH * waterMask);
    color.rgb *= mix(vec3(1.0), vec3(0.90, 1.03, 1.08), WATER_TINT_STRENGTH * waterMask);
#endif
#ifdef ENABLE_WATER_HIGHLIGHTS
    if (waterMask > 0.5) {
        vec3 n = normalize(viewNormal);
        vec3 v = normalize(viewDirection);
        vec3 sunDir = normalize(sunPosition);
        vec3 moonDir = normalize(moonPosition);
        float sunGlint = pow(max(dot(reflect(-sunDir, n), v), 0.0), 48.0);
        float moonGlint = pow(max(dot(reflect(-moonDir, n), v), 0.0), 48.0);
        float nightInWater = clamp((float(worldTime) - 12000.0) / 3000.0, 0.0, 1.0);
        float nightOutWater = clamp((24000.0 - float(worldTime)) / 3000.0, 0.0, 1.0);
        float nightWater = nightInWater * nightOutWater;
        float glint = sunGlint * (1.0 - nightWater) + moonGlint * nightWater * 0.25;
        vec3 glintColor = mix(vec3(1.0, 0.82, 0.58), vec3(0.52, 0.64, 0.88), nightWater);
        color.rgb += glintColor * glint * WATER_HIGHLIGHT_STRENGTH;
    }
#endif
#ifdef ENABLE_EMISSIVE_CORE
    float coreLuminance = dot(texel.rgb, vec3(0.299, 0.587, 0.114));
    float warmCore = max(texel.r, texel.g) - texel.b;
    float coreMask = smoothstep(0.36, 0.82, coreLuminance)
                   * smoothstep(0.04, 0.28, warmCore)
                   * sourceBlock;
    color.rgb += color.rgb * coreMask * EMISSIVE_CORE_STRENGTH * 0.80;
#endif

    gl_FragData[0] = color;
}





