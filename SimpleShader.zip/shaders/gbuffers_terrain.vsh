#version 120

attribute vec2 mc_Entity;
uniform mat4 gbufferModelViewInverse;

varying vec4 vertexColor;
varying vec2 texcoord;
varying vec2 lightCoord;
varying vec3 worldNormal;
varying float sourceBlock;
varying float fluidSurface;
varying vec3 playerPosition;
varying vec3 viewDirection;
varying vec3 viewNormal;

void main() {
    gl_Position = ftransform();
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).st;
    lightCoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).st;
    vertexColor = gl_Color;
    sourceBlock = (mc_Entity.x == 100.0) ? 1.0 : 0.0;
    fluidSurface = clamp(mc_Entity.y, 0.0, 1.0);

    vec3 viewPos = (gl_ModelViewMatrix * gl_Vertex).xyz;
    playerPosition = (gbufferModelViewInverse * vec4(viewPos, 1.0)).xyz;
    viewDirection = normalize(-viewPos);
    viewNormal = normalize(gl_NormalMatrix * gl_Normal);
    worldNormal = normalize(mat3(gbufferModelViewInverse) * viewNormal);
}
