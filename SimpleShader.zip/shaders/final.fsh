#version 120

#define SATURATION 1.0 // [0.0 0.5 0.75 1.0 1.1 1.25 1.5] Color saturation
#define FOG_STRENGTH 0.35 // [0.0 0.25 0.5 0.75 1.0] Distance fog strength
#define ENABLE_DISTANCE_FOG // Toggle distance fog

uniform sampler2D colortex0;
uniform sampler2D depthtex0;
uniform mat4 gbufferProjectionInverse;
uniform vec3 fogColor;
uniform float far;
uniform float viewWidth;
uniform float viewHeight;
varying vec2 texcoord;

vec3 brightWarmPart(vec3 sampleColor) {
    float brightness = max(sampleColor.r, max(sampleColor.g, sampleColor.b));
    float warm = sampleColor.r - sampleColor.b;
    float brightMask = smoothstep(0.62, 0.90, brightness);
    float warmMask = smoothstep(-0.04, 0.20, warm);
    return sampleColor * brightMask * warmMask;
}

void main() {
    vec4 scene = texture2D(colortex0, texcoord);
    vec3 color = scene.rgb;

    // Restrained contrast, saturation, and warmth adjustment.
    color = (color - 0.5) * 1.045 + 0.5;
    float luminance = dot(color, vec3(0.299, 0.587, 0.114));
    color = mix(vec3(luminance), color, SATURATION);
    color *= vec3(1.012, 1.006, 0.992);

#ifdef ENABLE_DISTANCE_FOG
    float depth = texture2D(depthtex0, texcoord).r;
    if (depth < 0.99999) {
        vec4 clipPosition = vec4(texcoord * 2.0 - 1.0, depth * 2.0 - 1.0, 1.0);
        vec4 viewPosition = gbufferProjectionInverse * clipPosition;
        viewPosition.xyz /= viewPosition.w;
        float distanceToPixel = length(viewPosition.xyz);
        float fogAmount = smoothstep(far * 0.55, far * 0.95, distanceToPixel);
        fogAmount *= FOG_STRENGTH;
        color = mix(color, fogColor, fogAmount);
    }
#endif

gl_FragColor = vec4(clamp(color, 0.0, 1.0), scene.a);
}

