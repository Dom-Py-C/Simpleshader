SimpleShader — lightweight Iris shader pack

Install
1. Place SimpleShader.zip in .minecraft/shaderpacks (or your launcher's shaderpacks folder).
2. Select SimpleShader in Iris, then open its Shader Pack Settings.
3. Water remains dark by default, with optional sun/moon glints. Other visual effects are controlled in Shader Pack Settings.

Performance
When enabled, Soft Emissive Glow adds four screen-color texture reads per output pixel and no extra render pass or buffer. Leave it off on slower GPUs if its cost is noticeable. Other lighting effects use the existing terrain pass. Distance fog adds one depth texture read per screen pixel while enabled.

The pack targets Iris with GLSL 1.20 compatibility. Effects have in-game toggles and strength controls.

